
<?php
include ('connection.php');
if (isset($_GET['delete'])) {
  $id=$_GET['delete'];
  $delete=mysqli_query($conn,"DELETE FROM product_to_sell WHERE pts_id='$id'");
}
include ('header.php');
?>
<style>
    .activp{
        background-color: rgba(0, 0, 0, 0.7);
        border-radius: 0px 100px 100px 0px;
        border-left: 4px solid tomato;

    }
</style>
<!-- <main class="app-content"> -->
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Product to Sell</h1>
          <p>Here you will found the product that is able to sold</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-plus"></i></li>
          <!-- <li class="breadcrumb-item">Tables</li> -->
          <li class="breadcrumb-item active"><a href="add_product_to_sell.php">Add Product to sell</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Size</th>
                    <th>Price</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                        include ('connection.php');
                        $sql="SELECT * FROM product_to_sell,products WHERE product_to_sell.product_id=products.product_id ORDER BY pts_id DESC";
                        $select=mysqli_query($conn,$sql);
                        $sum=0;
                        while ($rows=mysqli_fetch_array($select)) {
                          ?>
                  <tr>
                    <td><?=$sum+=1?></td>
                  <td><img src="uploaded_file/<?php echo $rows['pts_image']?>" alt="Course"  style="width: 5rem; height: 4rem; border-radius: 5px"></td>
                  <td><?=$rows['pro_name']?></td>
                  <td><?=$rows['pts_size']?></td>
                  <td>$ <?=$rows['pro_price']?></td>
                  <td><a href="product_to_sell_dash.php?delete=<?=$rows['pts_id']?>"><i class="fa fa-trash text-danger" style="font-size: 25px"></i></a><a href=""><i class="fa fa-edit text-primary" style="font-size: 25px;margin-left: 15px"></i></a></td>
                  </tr>
                  <?php
                        }
                        ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
    <!-- </main> -->
    <?php
    include ('footer.php');
    ?>