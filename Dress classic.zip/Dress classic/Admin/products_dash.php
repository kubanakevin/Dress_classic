<?php
include ('connection.php');

if (isset($_GET['delete'])) {
  $id=$_GET['delete'];
  $delete=mysqli_query($conn,"DELETE FROM products WHERE product_id='$id'");
}

include ('header.php');
?>
<style>
    .activpd{
        background-color: rgba(0, 0, 0, 0.7);
        border-radius: 0px 100px 100px 0px;
        border-left: 4px solid tomato;

    }
</style>
<!-- <main class="app-content"> -->
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Products</h1>
          <p>Table to display analytical data effectively</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-plus"></i></li>
          <!-- <li class="breadcrumb-item">Tables</li> -->
          <li class="breadcrumb-item active"><a href="add_product.php">Add Product</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Product Type</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                        include ('connection.php');
                        $sql="SELECT * FROM products";
                        $select=mysqli_query($conn,$sql);
                        while ($rows=mysqli_fetch_array($select)) {
                          ?>
                  <tr>
                  <td><img src="uploaded_file/<?php echo $rows['pro_image']?>" alt="Course"  style="width: 5rem; height: 4rem; border-radius: 5px"></td>
                  <td><?=$rows['pro_name']?></td>
                  <td><?=$rows['pro_type']?></td>
                  <td><a href="products_dash.php?delete=<?=$rows['product_id']?>"><i class="fa fa-trash text-danger" style="font-size: 25px"></i></a><a href=""><i class="fa fa-edit text-primary" style="font-size: 25px;margin-left: 15px"></i></a></td>
                  </tr>
                  <?php
                        }
                        ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
    <!-- </main> -->
    <?php
    include ('footer.php');
    ?>