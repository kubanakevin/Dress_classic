<?php
include ('connection.php');
if (isset($_POST['save'])) {
  $p_n = $_POST['product_id'];
  $image = $_FILES['pro_image']['name'];
  $image_tmp_name = $_FILES['pro_image']['tmp_name'];
  $image_folder = "uploaded_file/".$image;
  $p_p = $_POST['pro_price'];
  $sql = "INSERT INTO product_to_sell (product_id,pts_image,pro_price) VALUES('$p_n','$image','$p_p')";
  $res = mysqli_query($conn, $sql);
  if ($res) {
     move_uploaded_file($image_tmp_name, $image_folder);
     header('location: product_to_sell_dash.php');
  }else {
     echo "<script>alert('Fail to add product to sell try again')</script>";
     echo "<script> history.back()</script>";
  }
}
?>
<?php
include ('header.php');
?>
<style>
    .activp{
        background-color: rgba(0, 0, 0, 0.7);
        border-radius: 0px 100px 100px 0px;
        border-left: 4px solid tomato;

    }
</style>
<div class="row">
        <div class="col-md-6">
          <div class="tile">
            <h3 class="tile-title">Add Product To Sell</h3>
            <div class="tile-body">
              <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                  <label class="control-label">Product Name</label>
                  <select name="product_id" id="" class="form-control">
                    <?php
                    $select=mysqli_query($conn, "SELECT * FROM products");
                    while ($row=mysqli_fetch_array($select)) {
                        ?>
                        <option value="<?=$row['product_id']?>"><?=$row['pro_name']?></option>
                        <?php
                    }
                    ?>
                  </select>
                </div>
                
                <div class="form-group">
                  <label class="control-label">Product Image</label>
                  <input class="form-control" type="file" name="pro_image">
                </div>
                <div class="from-group">
                    <label for="Product Price">Product Price</label>
                    <input type="number" name="pro_price" id="" class="form-control" placeholder="Enter Product Price">
                </div>
                <div class="tile-footer">
                    <button class="btn btn-primary col-lg-12 col-sm-12 col-md-12" name="save" type="submit"><i class="fa fa-fw fa-lg fa-plus"></i>Add Product to Sell</button>&nbsp;&nbsp;&nbsp;
                </div>
              </form>
            </div>
            
          </div>
        </div>
        
        <div class="clearix"></div>
        
      </div>
<?php
include ('footer.php');
?>