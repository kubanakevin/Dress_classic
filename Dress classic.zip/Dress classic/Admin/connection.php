<?php
$conn = mysqli_connect("localhost","root","","dress_classic") or die("connection fail");
?>