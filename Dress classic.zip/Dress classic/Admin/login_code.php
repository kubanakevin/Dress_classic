<?php
include ('connection.php');
session_start();
if (isset($_POST['login'])) {
    // $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $login=mysqli_query($conn,"SELECT * FROM users WHERE email='$email' AND password='$password'");
    $num=mysqli_num_rows($login);
    $data=mysqli_fetch_array($login);
    if ($num > 0) {
       $_SESSION['username']=$data['username'];
       $_SESSION['email']=$data['email'];
       $_SESSION['password']=$data['password'];
       $_SESSION['image']=$data['image'];
       header('location: dashboard.php');
    // echo "<script> alert('Well done')</script>";
    }else {
        echo "<script> alert('Incorrect Email/Password!')</script>";
        echo "<script>history.back()</script>";
    }
}
?>