<?php
include ('header.php');
?>
<style>
    .activp{
        background-color: rgba(0, 0, 0, 0.7);
        border-radius: 0px 100px 100px 0px;
        border-left: 4px solid tomato;

    }
</style>
<div class="row ">
<div class="col-md-6">
          <div class="tile">
            <?php
          include ('connection.php');
                if (isset($_GET['delete'])) {
                  $id=$_GET['delete'];
                  $trash="SELECT * FROM product_sold,products WHERE product_sold.product_id=products.product_id AND ps_id='$id'";
                  $result = mysqli_query($conn, $trash);
                  while ($data=mysqli_fetch_array($result)) {
                    ?>
            <h3 class="tile-title"><?=$data['pro_name']?></h3>
            <div class="tile-body">
            <img src="uploaded_file/<?php echo $data['ps_image']?>" alt="Course"  class="col-lg-12" style="height: 20rem;border-radius: 10px;">
              <!-- <img src="uploaded_file/product 3.jpg" alt="" ></div> -->
            <?php
                }
              }
                ?>
            <div class="tile-footer">
              <?php
              include ('connection.php');
              if (isset($_GET['delete'])) {
                $id=$_GET['delete'];
                $trash="SELECT * FROM product_sold WHERE ps_id='$id'";
                $result = mysqli_query($conn, $trash);
                while ($data=mysqli_fetch_array($result)) {
                  ?>
    <form action="" method="POST">
      <input type="hidden" name="product_id" value="<?=$data['product_id']?>">
      <input type="hidden" name="ps_price" value="<?=$data['ps_price']?>">
      <input type="hidden" name="ps_size" value="<?=$data['ps_size']?>">
      <input type="hidden" name="cust_name" value="<?=$data['cust_name']?>">
      <input type="hidden" name="cust_tel" value="<?=$data['cust_tel']?>">
      <input type="hidden" name="ps_image" value="<?=$data['ps_image']?>">
      <input type="hidden" name="order_note" value="<?=$data['order_note']?>">
      <input type="hidden" name="o_time" value="<?=$data['o_time']?> ">
      <h4>Are you sure you want to delete this data</h4>
      <input type="submit" value="Yes" name="save" class="btn btn-danger col-lg-4">
      <!-- <input type="reset" value="Cancel" class="btn btn-success"> -->
      <a href="solded_dash.php" class="btn btn-success col-lg-4">No</a>
    </form>
    <?php
  }
  if (isset($_POST['save'])) {

  $pro_id=$_POST['product_id'];
  $p_price = $_POST['ps_price'];
  $p_size = $_POST['ps_size'];
  $c_name = $_POST['cust_name'];
  $c_tel = $_POST['cust_tel'];
  $p_img = $_POST['ps_image'];
  $o_note = $_POST['order_note'];
  $o_time = $_POST['o_time'];
    $sql="INSERT INTO trash (product_id,p_price,p_size,cus_name,cus_tel,p_image,o_note,o_time) VALUES('$pro_id','$p_price','$p_size','$c_name','$c_tel','$p_img','$o_note','$o_time')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
          $id=$_GET['delete'];
          $delete=mysqli_query($conn,"DELETE FROM product_sold WHERE ps_id='$id'"); 
          if ($delete) {
            echo "<script> alert('Product Deleted successfully!')</script>";
            echo "<script> window.location.href='solded_dash.php'</script>";
          }
    }
  }
}
?></div>
          </div>
        </div>
</div>

<?php
include ('footer.php');
?>