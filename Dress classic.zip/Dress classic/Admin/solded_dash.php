<?php

// }
include ('header.php');
?>
<style>
    .activ{
        background-color: rgba(0, 0, 0, 0.7);
        border-radius: 0px 100px 100px 0px;
        border-left: 4px solid tomato;

    }
</style>
<!-- <main class="app-content"> -->
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Products that solded</h1>
          <p>List of all solded products in stock and the information of people who bought it</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-plus"></i></li>
          <!-- <li class="breadcrumb-item">Tables</li> -->
          <li class="breadcrumb-item active"><a href="#">Sell Product</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Customer Name</th>
                    <th>Customer tel</th>
                    <th>Order Note</th>
                    <th>Order Time</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                        include ('connection.php');
                        $sql="SELECT * FROM product_sold,products WHERE product_sold.product_id=products.product_id ORDER BY ps_id DESC";
                        $select=mysqli_query($conn,$sql);
                        $sum=0;
                        while ($rows=mysqli_fetch_array($select)) {
                          ?>
                  <tr>
                  <td><img src="uploaded_file/<?php echo $rows['ps_image']?>" alt="Course"  style="width: 5rem; height: 4rem; border-radius: 5px"></td>
                  <td><?=$rows['pro_name']?></td>
                  <td><?=$rows['ps_price']?> Rwf</td>
                  <td><?=$rows['cust_name']?></td>
                  <td><?=$rows['cust_tel']?></td>
                  <td><?=$rows['order_note']?></td>
                  <td><?=$rows['o_time']?></td>
                  <td><a href="move_to_trash.php?delete=<?=$rows['ps_id']?>"><i class="fa fa-trash text-danger" style="font-size: 25px"></i></a></td>
                  </tr>
                  <?php
                        }
                        ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
    <!-- </main> -->
    <?php
    include ('footer.php');
    ?>