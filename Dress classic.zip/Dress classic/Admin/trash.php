<?php
include ('connection.php');

if (isset($_GET['delete'])) {
  $id=$_GET['delete'];
  $delete=mysqli_query($conn,"DELETE FROM trash WHERE trash_id='$id'");
}

// }
include ('header.php');
?>
<style>
    .activet{
        background-color: rgba(0, 0, 0, 0.7);
        border-radius: 0px 100px 100px 0px;
        border-left: 4px solid tomato;

    }
</style>
<!-- <main class="app-content"> -->
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Data that Deleted</h1>
          <p>List of all Delete Data in stock </p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-trash"></i></li>
          <!-- <li class="breadcrumb-item">Tables</li> -->
          <li class="breadcrumb-item active"><a href="#">Empty trash</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Product Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Size</th>
                    <th>Customer Name</th>
                    <th>Customer tel</th>
                    <th>Orderd Time</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                        include ('connection.php');
                        $sql="SELECT * FROM trash,products WHERE trash.product_id=products.product_id ORDER BY trash_id DESC";
                        $select=mysqli_query($conn,$sql);
                        $sum=0;
                        while ($rows=mysqli_fetch_array($select)) {
                          ?>
                  <tr>
                  <td><img src="uploaded_file/<?php echo $rows['p_image']?>" alt="Course"  style="width: 5rem; height: 4rem; border-radius: 5px"></td>
                  <td><?=$rows['pro_name']?></td>
                  <td><?=$rows['p_price']?> Rwf</td>
                  <td><?=$rows['p_size']?> </td>
                  <td><?=$rows['cus_name']?></td>
                  <td><?=$rows['cus_tel']?></td>
                  <td><?=$rows['o_time']?></td>
                  <td><a href="trash.php?delete=<?=$rows['trash_id']?>"><i class="fa fa-trash text-danger" style="font-size: 25px"></i></a><i class="fa fa-download text-primary" style="font-size: 25px;margin-left: 15px"></i></td>
                  </tr>
                  <?php
                        }
                        ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
    <!-- </main> -->
    <?php
    include ('footer.php');
    ?>