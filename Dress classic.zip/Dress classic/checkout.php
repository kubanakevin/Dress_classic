<!-- /*
* Bootstrap 5
* Template Name: Furni
* Template Author: Untree.co
* Template URI: https://untree.co/
* License: https://creativecommons.org/licenses/by/3.0/
*/ -->
<?php
include ('connection.php');
$id=$_GET['id'];
if (isset($_POST['save'])) {
    $p_n=$_POST['product_id'];
    $p_s=$_POST['ps_size'];
    $p_p=$_POST['pro_price'];
    $c_n=$_POST['cust_name'];
    $c_t=$_POST['cust_tel'];
    $p_i=$_POST['pro_image'];
    $o_n=$_POST['order_note'];
	$sql="INSERT INTO product_sold (product_id,ps_size,ps_price,cust_name,cust_tel,ps_image,order_note) VALUES('$p_n','$p_s','$p_p','$c_n','$c_t','$p_i','$o_n')";
	$result = mysqli_query($conn,$sql);
	if ($result) {
		$delete="DELETE FROM product_to_sell WHERE pts_id='$id'";
		$res=mysqli_query($conn,$delete);
		if ($res) {
			header('location: thankyou.php');
		}
		// header('location: thankyou.php');
	}
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="images/icon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>Dress classic and sell product you wont</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
		<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

			<div class="container">
				<a class="navbar-brand" href="index.html">Dress Classic<span>.</span></a>

				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarsFurni">
					<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
						<li class="nav-item ">
							<a class="nav-link" href="index.php">Home</a>
						</li>
						<li><a class="nav-link" href="shop.php">Shop</a></li>
						<li><a class="nav-link" href="about.html">About us</a></li>
						<li><a class="nav-link" href="services.html">Services</a></li>
						<li><a class="nav-link" href="blog.html">Blog</a></li>
						<li><a class="nav-link" href="contact.html">Contact us</a></li>
					</ul>

					<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
						<li><a class="nav-link" href="#"><img src="images/user.svg"></a></li>
						<li><a class="nav-link" href="cart.html"><img src="images/cart.svg"></a></li>
					</ul>
				</div>
			</div>
				
		</nav>
		

		<div class="untree_co-section">
		    <div class="container">
		      
		      <div class="row">
			  <?php
					include ('connection.php');
					$id=$_GET['id'];
					$sql="SELECT * FROM product_to_sell,products WHERE product_to_sell.product_id=products.product_id AND pts_id='$id'";
					$select=mysqli_query($conn,$sql);
					while ($rows=mysqli_fetch_array($select)) {
					  ?>
			  <div class="col-md-6">
		          <div class="row mb-5">
		            <div class="col-md-12">
		              <h2 class="h3 mb-3 text-black">Your Order</h2>
		              <div class="p-3 p-lg-5 border bg-white">
		                <table class="table site-block-order-table mb-5">
		                  <thead>
		                    <th>Product Name</th>
		                    <th>Amount</th>
		                  </thead>
		                  <tbody>
		                    <tr>
		                      <td> <strong class="mx-2"><?=$rows['pro_name']?></strong> </td>
		                      <td><?=$rows['pro_price']?> Rwf</td>
		                    </tr>
		                    
		                  </tbody>
		                </table>
						<div class="img col-lg-12 col-sm-12 col-md-12">
							<!-- <img src="images/product-1.png" class="col-lg-12 col-sm-12 col-md-12" style="width: 100%;" alt=""> -->
							<a href="../Dress classic/Admin/uploaded_file/<?php echo $rows['pts_image']?>"><img src="../Dress classic/Admin/uploaded_file/<?php echo $rows['pts_image']?>" alt="Course" class="col-lg-12 col-sm-12" style="width: 100%"></a>
						</div>

		                <!-- <div class="form-group">
		                  <button class="btn btn-black btn-lg py-3 btn-block" onclick="window.location='thankyou.html'">Place Order</button>
		                </div> -->
						
		              </div>
		            </div>
		          </div>

		        </div>


		        <div class="col-md-6 mb-5 mb-md-0">
		          <h2 class="h3 mb-3 text-black">Billing Details</h2>
		          <div class="p-3 p-lg-5 border bg-white">
					<form action="" method="POST">
					<div class="form-group row">
						<!-- <div class="col-md-12">
						  <label for="email" class="text-black">Product Name </label>
						  <input type="text" class="form-control" id="c_companyname" readonly name="c_companyname">
						</div> -->
					  </div>
					  
					  <div class="col-md-12">
						  <input type="hidden" value="<?=$rows['product_id']?>" name="product_id" class="form-control">
						</div>
		            <div class="form-group">
		              <label for="c_country" class="text-black">Size of Product<span class="text-danger">*</span></label>
		              <select id="c_country" name="ps_size" class="form-control" required>
		                <option value="">Select a Size</option>    
		                <option value="45">45</option>    
		                <option value="46">46</option>    
		                <option value="47">47</option>    
		                <option value="48">48</option>    
		                <option value="49">49</option>    
		                <option value="50">50</option>    
		                <option value="51">51</option>    
		                <option value="52">52</option>    
		              </select>
		            </div>
					<div class="form-group row">
		              <div class="col-md-12">
					    <input type="hidden" value="<?=$rows['pro_price']?>" class="form-control" id="c_address" name="pro_price">
		              </div>
		            </div>

		            <div class="form-group row">
		              <div class="col-md-12">
		                <label for="email" class="text-black">Customer Names</label>
		                <input type="text" class="form-control" id="c_companyname" name="cust_name" placeholder="Enter Your names">
		              </div>
		            </div>

		            <div class="form-group row">
		              <div class="col-md-12">
		                <label for="c_address" class="text-black">Telephone <span class="text-danger">*</span></label>
		                <input type="tel" class="form-control" id="c_address" name="cust_tel" placeholder="Enter Telephone">
		              </div>
		            </div>
		            
					<input type="hidden" value="<?=$rows['pts_image']?>" class="form-control" id="c_address" name="pro_image">
					

		            <div class="form-group">
		              <label for="c_order_notes" class="text-black">Order Notes</label>
		              <textarea name="order_note" id="c_order_notes" cols="30" rows="4" class="form-control" placeholder="Write your notes here..."></textarea>
		            </div>
					<div class="card-footer">
						<input type="submit" value="Place Order" name="save" class="btn btn-primary col-lg-12 col-sm-12 col-md-12">
					</div>
					</form>
		          </div>
		        </div>
		        
				<?php
					}
					?>
		      </div>
		      <!-- </form> -->
		    </div>
		  </div>

		<!-- Start Footer Section -->
		<footer class="footer-section">
			<div class="container relative">

				<div class="sofa-img">
					<img src="images/image mover.png" alt="Image" class="img-fluid">
				</div>

				<div class="row">
					<div class="col-lg-8">
						<div class="subscription-form">
							<h3 class="d-flex align-items-center"><span class="me-1"><img src="images/envelope-outline.svg" alt="Image" class="img-fluid"></span><span>Subscribe to Newsletter</span></h3>

							<form action="#" class="row g-3">
								<div class="col-auto">
									<input type="text" class="form-control" placeholder="Enter your name">
								</div>
								<div class="col-auto">
									<input type="email" class="form-control" placeholder="Enter your email">
								</div>
								<div class="col-auto">
									<button class="btn btn-primary">
										<span class="fa fa-paper-plane">Subscribe</span>
									</button>
								</div>
							</form>

						</div>
					</div>
				</div>

				<div class="row g-5 mb-5">
					<div class="col-lg-4">
						<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Dress Classic<span>.</span></a></div>
						<p class="mb-4">Our company offers stylish, high-quality clothing designed to make you feel confident and unique.</p>

						<ul class="list-unstyled custom-social">
							<li><a href="https://www.facebook.com/"><span class="fa fa-brands fa-facebook-f"></span></a></li>
							<li><a href="https://x.com/home"><span class="fa fa-brands fa-twitter"></span></a></li>
							<li><a href="https://www.instagram.com/direct/inbox/"><span class="fa fa-brands fa-instagram"></span></a></li>
							<li><a href="https://www.linkedin.com/feed/"><span class="fa fa-brands fa-linkedin"></span></a></li>
						</ul>
					</div>

					<div class="col-lg-8">
						<div class="row links-wrap">
							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="about.html">About us</a></li>
									<li><a href="services.html">Services</a></li>
									<li><a href="blog.html">Blog</a></li>
									<li><a href="contact.html">Contact us</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="contact.html">Support</a></li>
									<li><a href="about.html">Knowledge base</a></li>
									<li><a href="https://web.whatsapp.com/">Live chat</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="about.html">Jobs</a></li>
									<li><a href="about.html">Our team</a></li>
									<li><a href="about.html">Leadership</a></li>
									<li><a href="contact.html">Privacy Policy</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="shop.html">Sandals shoes</a></li>
									<li><a href="shop.html">Sneakers shoes</a></li>
									<li><a href="shop.html">Flats shoes</a></li>
									<li><a href="shop.html">Made in Rwanda</a></li>

								</ul>
							</div>
						</div>
					</div>

				</div>

				<div class="border-top copyright">
					<div class="row pt-4">
						<div class="col-lg-6">
							<p class="mb-2 text-center text-lg-start">Copyright &copy;<script>document.write(new Date().getFullYear());</script>. All Rights Reserved. <br> &mdash; Designed with love by <a href="https://untree.co">Byiringiro Theogene <br>more info call(+250787016860)
								
							</a> Distributed By <a hreff="https://themewagon.com">B.T software industry</a>  <!-- License information: https://untree.co/license/ -->
            </p>
						</div>

						<div class="col-lg-6 text-center text-lg-end">
							<ul class="list-unstyled d-inline-flex ms-auto">
								<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>

					</div>
				</div>

			</div>
		</footer>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
