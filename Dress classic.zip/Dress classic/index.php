<!-- /*
* Bootstrap 5
* Template Name: Furni
* Template Author: Untree.co
* Template URI: https://untree.co/
* License: https://creativecommons.org/licenses/by/3.0/
*/ -->
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="Untree.co">
  <link rel="shortcut icon" href="images/icon.png">

  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

		<!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<title>Dress classic and sell product you wont1</title>
	</head>

	<body>

		<!-- Start Header/Navigation -->
		<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

			<div class="container">
				<a class="navbar-brand" href="index.html">Dress Classic<span>.</span></a>

				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarsFurni">
					<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
						<li class="nav-item active">
							<a class="nav-link" href="index.php">Home</a>
						</li>
						<li><a class="nav-link" href="shop.php">Shop</a></li>
						<li><a class="nav-link" href="about.html">About us</a></li>
						<li><a class="nav-link" href="services.html">Services</a></li>
						<li><a class="nav-link" href="blog.html">Blog</a></li>
						<li><a class="nav-link" href="contact.html">Contact us</a></li>
					</ul>

					<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
						<li><a class="nav-link" href="Admin/page-login.php"><img src="images/user.svg"></a></li>
						<li><a class="nav-link" href=""><img src="images/cart.svg"></a></li>
					</ul>
				</div>
			</div>
				
		</nav>
		<!-- End Header/Navigation -->

		<!-- Start Hero Section -->
			<div class="hero">
				<div class="container">
					<div class="row justify-content-between">
						<div class="col-lg-5">
							<div class="intro-excerpt">
								<h1>Modern Classic <span clsas="d-block">Cloths </span></h1>
								<p class="mb-4">Our company offers stylish, high-quality clothing designed to make you feel confident and unique. Choose us for exceptional designs and unbeatable comfort that elevate your wardrobe.</p>
								<p><a href="shop.html" class="btn btn-secondary me-2">Shop Now</a><a href="contact.html" class="btn btn-white-outline">Let's talk</a></p>
							</div>
						</div>
						<div class="col-lg-7 com-sm-12 col-md-12">
							<div class="hero-img-wrap">
								<img src="images/g oness.png" class="img-fluid" style="margin-top: 3rem; margin-left: 10rem;">
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-- End Hero Section -->

		<!-- Start Product Section -->
		<div class="product-section">
			<div class="container">
				<div class="row">

					<!-- Start Column 1 -->
					<div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
						<h2 class="mb-4 section-title">Crafted with excellent Dresses.</h2>
						<p class="mb-4">Working with me means collaboration, innovation, and results. I bring dedication, problem-solving skills, and a proactive mindset to ensure we achieve our shared goals efficiently and effectively. </p>
						<p><a href="shop.html" class="btn">Explore</a></p>
					</div> 
					<!-- End Column 1 -->

					<!-- Start Column 2 -->
					<?php
					include ('connection.php');
					$sql="SELECT * FROM product_to_sell,products WHERE product_to_sell.product_id=products.product_id ORDER BY pts_id DESC LIMIT 7";
					$select=mysqli_query($conn,$sql);
					while ($rows=mysqli_fetch_array($select)) {
					  ?>
					<div class="col-12 col-md-4 col-lg-3 col-sm-12 mb-5 mb-md-0">
						<a class="product-item" href="checkout.php?id=<?=$rows['pts_id']?>">
							<!-- <img src="images/image6.png" class="img-fluid product-thumbnail"> -->
							<!-- <img src="../Rangisha/Admin_dashboard/advitise_file/<?php echo $rows['adv_image']?>" alt="Course"> -->
							 <div class="image col-lg-12 col-md-12 col-sm-12">
							<img src="../Dress classic/Admin/uploaded_file/<?php echo $rows['pts_image']?>" alt="Course" class="col-lg-12 col-sm-12" style="width: 100%">
							 </div>
							<br><br><h3 class="product-title"><?=$rows['pro_name']?></h3>
							<strong class="product-price"><?=$rows['pro_price']?> Rwf</strong><br>
							<strong class="product-price"><?=$rows['pts_size']?> </strong>

							<span class="icon-cross">
								<img src="images/cart.svg" class="img-fluid">
								<!-- <i class="fa fa-home" class="img-fluid"></i> -->
							</span>
						</a>
					</div> 
					<?php
					}
					?>
					<!-- End Column 2 -->

					
				</div>
			</div>
		</div>
		<!-- End Product Section -->

		<!-- Start Why Choose Us Section -->
		<div class="why-choose-section">
			<div class="container">
				<div class="row justify-content-between">
					<div class="col-lg-6">
						<h2 class="section-title">Why Choose Us</h2>
						<p>You should choose our website because we offer a wide range of stylish, high-quality dresses at affordable prices. With excellent customer service, secure shopping, and fast delivery, we make your fashion experience seamless and enjoyable.</p>

						<div class="row my-5">
							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/truck.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>Fast &amp; Free Shipping</h3>
									<p>free delivary everywhere you are and we are here for you.</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/bag.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>Easy to Shop</h3>
									<p>easy to buy everythings about you wont </p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/support.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>24/7 Support</h3>
									<p>we are available every hours or everytime</p>
								</div>
							</div>

							<div class="col-6 col-md-6">
								<div class="feature">
									<div class="icon">
										<img src="images/return.svg" alt="Image" class="imf-fluid">
									</div>
									<h3>Hassle Free Returns</h3>
									<p>We offer a hassle-free return service, allowing you to easily return products if you're not satisfied or if they don't meet quality standards, ensuring a worry-free shopping experience.</p>
								</div>
							</div>

						</div>
					</div>

					<div class="col-lg-5">
						<div class="img-wrap">
							<img src="images/g one.jpg" alt="Image" class="img-fluid" style="height: 32rem; width: 40rem;">
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- End Why Choose Us Section -->

		<!-- Start We Help Section -->
		<div class="we-help-section">
			<div class="container">
				<div class="row justify-content-between">
					<div class="col-lg-7 mb-5 mb-lg-0">
						<div class="imgs-grid">
							<div class="grid grid-1"><img src="images/card-large-item10.jpg" alt="Untree.co"></div>
							<div class="grid grid-2"><img src="images/card-large-item11.jpg" alt="Untree.co"></div>
							<div class="grid grid-3"><img src="images/card-large-item7.jpg" alt="Untree.co"></div>
						</div>
					</div>
					<div class="col-lg-5 ps-lg-5">
						<h2 class="section-title mb-4">We Help You Make Modern Interior Design</h2>
						<p>Welcome to our online store, where fashion meets convenience! We offer a wide variety of stylish dresses, designed to fit every occasion, with easy shopping and fast delivery, so you can look your best effortlessly.</p>

						<ul class="list-unstyled custom-list my-4">
							<li>We provide dresses and everthin you wont buy</li>
							<li>we provide client thing you wont</li>
							<li>we available to make good dresses</li>
							<li>with our team and with success</li>
						</ul>
						<p><a herf="shop.html" class="btn">see all</a></p>
					</div>
				</div>
			</div>
		</div>
		<!-- End We Help Section -->

		<!-- Start Popular Product -->
		<div class="popular-product">
			<div class="container">
				<div class="row">

					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="images/sandals.jpg" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3>Sandals shoes</h3>
								<p>classic shoes available here about to dress your purpose you wont</p>
								<p><a href="#">Read More</a></p>
							</div>
						</div>
					</div>

					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="images/senekers.jpg" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3>Sneakers shoes</h3>
								<p>shoes like using sport and anything you wont </p>
								<p><a href="#">Read More</a></p>
							</div>
						</div>
					</div>

					<div class="col-12 col-md-6 col-lg-4 mb-4 mb-lg-0">
						<div class="product-item-sm d-flex">
							<div class="thumbnail">
								<img src="images/flat.jpg" alt="Image" class="img-fluid">
							</div>
							<div class="pt-3">
								<h3>Flats shoes</h3>
								<p>flats shoes that is classic of dressing and so </p>
								<p><a href="#">Read More</a></p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- End Popular Product -->

		<!-- Start Testimonial Slider -->
		<div class="testimonial-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-7 mx-auto text-center">
						<h2 class="section-title">Hair recent client</h2>
					</div>
				</div>

				<div class="row justify-content-center">
					<div class="col-lg-12">
						<div class="testimonial-slider-wrap text-center">

							<div id="testimonial-nav">
								<span class="prev" data-controls="prev"><span class="fa fa-chevron-left"></span></span>
								<span class="next" data-controls="next"><span class="fa fa-chevron-right"></span></span>
							</div>

							<div class="testimonial-slider">
								
								<div class="item">
									<div class="row justify-content-center">
										<div class="col-lg-8 mx-auto">

											<div class="testimonial-block text-center">
												<blockquote class="mb-5">
													<p>&ldquo;
														I absolutely love shopping on this website! The clothing is stylish, high-quality, and always arrives quickly—it's my go-to for all my fashion needs!.&rdquo;</p>
												</blockquote>

												<div class="author-info">
													<div class="author-pic">
														<img src="images/kevin.jpg" alt="Maria Jones" class="img-fluid">
													</div>
													<h3 class="font-weight-bold">Kubana Kevin</h3>
													<span class="position d-block mb-3">back-end developer.</span>
												</div>
											</div>

										</div>
									</div>
								</div> 
								<!-- END item -->

								<div class="item">
									<div class="row justify-content-center">
										<div class="col-lg-8 mx-auto">

											<div class="testimonial-block text-center">
												<blockquote class="mb-5">
													<p>&ldquo;This website has everything I need, from trendy outfits to everyday essentials. The prices are great, and the customer service is outstanding—I always recommend it to my friends!.&rdquo;</p>
												</blockquote>

												<div class="author-info">
													<div class="author-pic">
														<img src="images/ceo.jpg" alt="Maria Jones" class="img-fluid">
													</div>
													<h3 class="font-weight-bold">Byiringiro Theogene</h3>
													<span class="position d-block mb-3">CEO.</span>
												</div>
											</div>

										</div>
									</div>
								</div> 
								<!-- END item -->

								<div class="item">
									<div class="row justify-content-center">
										<div class="col-lg-8 mx-auto">

											<div class="testimonial-block text-center">
												<blockquote class="mb-5">
													<p>&ldquo;I've been shopping here for months, and I'm always impressed by the variety and quality of the products. The seamless ordering process and fast delivery make it a joy to shop every time!.&rdquo;</p>
												</blockquote>

												<div class="author-info">
													<div class="author-pic">
														<img src="images/cky.jpg" alt="Maria Jones" class="img-fluid">
													</div>
													<h3 class="font-weight-bold">Munezero christean(cky)</h3>
													<span class="position d-block mb-3">web developer</span>
												</div>
											</div>

										</div>
									</div>
								</div> 
								<!-- END item -->

							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Testimonial Slider -->

		<!-- Start Blog Section -->
		<div class="blog-section">
			<div class="container">
				<div class="row mb-5">
					<div class="col-md-6">
						<h2 class="section-title">Recent Blog</h2>
					</div>
					<div class="col-md-6 text-start text-md-end">
						<a href="blog.html" class="more">View All Posts</a>
					</div>
				</div>

				<div class="row">

					<div class="col-12 col-sm-6 col-md-4 mb-4 mb-md-0">
						<div class="post-entry">
							<a href="#" class="post-thumbnail"><img src="images/card-item2.jpg" alt="Image" class="img-fluid"></a>
							<div class="post-content-entry">
								<h3><a href="#">First Time Ideas you can buy this shoes</a></h3>
								<div class="meta">
									<span>by <a href="#">Kubana kevin</a></span> <span>on <a href="#">Dec 02, 2024</a></span>
								</div>
							</div>
						</div>
					</div>

					<div class="col-12 col-sm-6 col-md-4 mb-4 mb-md-0">
						<div class="post-entry">
							<a href="#" class="post-thumbnail"><img src="images/card-item4.jpg" alt="Image" class="img-fluid"></a>
							<div class="post-content-entry">
								<h3><a href="#">The way you use shoes like sport and so on...</a></h3>
								<div class="meta">
									<span>by <a href="#">Munezero christian</a></span> <span>on <a href="#">Dec 05, 2024</a></span>
								</div>
							</div>
						</div>
					</div>

					<div class="col-12 col-sm-6 col-md-4 mb-4 mb-md-0">
						<div class="post-entry">
							<a href="#" class="post-thumbnail"><img src="images/card-item5.jpg" alt="Image" class="img-fluid"></a>
							<div class="post-content-entry">
								<h3><a href="#">This shoes you can many jobs but it's classic</a></h3>
								<div class="meta">
									<span>by <a href="#">Byiringiro Theogene</a></span> <span>on <a href="#">Dec 12, 2024</a></span>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- End Blog Section -->	

		<!-- Start Footer Section -->
		<footer class="footer-section">
			<div class="container relative">

				<div class="sofa-img">
					<img src="images/image mover.png" alt="Image" class="img-fluid">
				</div>

				<div class="row">
					<div class="col-lg-8">
						<div class="subscription-form">
							<h3 class="d-flex align-items-center"><span class="me-1"><img src="images/envelope-outline.svg" alt="Image" class="img-fluid"></span><span>Subscribe to Newsletter</span></h3>

							<form action="#" class="row g-3">
								<div class="col-auto">
									<input type="text" class="form-control" placeholder="Enter your name">
								</div>
								<div class="col-auto">
									<input type="email" class="form-control" placeholder="Enter your email">
								</div>
								<div class="col-auto">
									<button class="btn btn-primary">
										<span class="fa fa-paper-plane">Subscribe</span>
									</button>
								</div>
							</form>

						</div>
					</div>
				</div>

				<div class="row g-5 mb-5">
					<div class="col-lg-4">
						<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Dress Classic<span>.</span></a></div>
						<p class="mb-4">Our company offers stylish, high-quality clothing designed to make you feel confident and unique.</p>

						<ul class="list-unstyled custom-social">
							<li><a href="https://www.facebook.com/"><span class="fa fa-brands fa-facebook-f"></span></a></li>
							<li><a href="https://x.com/home"><span class="fa fa-brands fa-twitter"></span></a></li>
							<li><a href="https://www.instagram.com/direct/inbox/"><span class="fa fa-brands fa-instagram"></span></a></li>
							<li><a href="https://www.linkedin.com/feed/"><span class="fa fa-brands fa-linkedin"></span></a></li>
						</ul>
					</div>

					<div class="col-lg-8">
						<div class="row links-wrap">
							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="about.html">About us</a></li>
									<li><a href="services.html">Services</a></li>
									<li><a href="blog.html">Blog</a></li>
									<li><a href="contact.html">Contact us</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="contact.html">Support</a></li>
									<li><a href="about.html">Knowledge base</a></li>
									<li><a href="https://web.whatsapp.com/">Live chat</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="about.html">Jobs</a></li>
									<li><a href="about.html">Our team</a></li>
									<li><a href="about.html">Leadership</a></li>
									<li><a href="contact.html">Privacy Policy</a></li>
								</ul>
							</div>

							<div class="col-6 col-sm-6 col-md-3">
								<ul class="list-unstyled">
									<li><a href="shop.html">Sandals shoes</a></li>
									<li><a href="shop.html">Sneakers shoes</a></li>
									<li><a href="shop.html">Flats shoes</a></li>
									<li><a href="shop.html">Made in Rwanda</a></li>

								</ul>
							</div>
						</div>
					</div>

				</div>

				<div class="border-top copyright">
					<div class="row pt-4">
						<div class="col-lg-6">
							<p class="mb-2 text-center text-lg-start">Copyright &copy;Dress classic. All Rights Reserved. <br> &mdash; Designed by <a href="https://untree.co">Byiringiro Theogene 								
							</a> Distributed By <a hreff="https://themewagon.com">B.T software industry</a>  <!-- License information: https://untree.co/license/ -->
            </p>
						</div>

						<div class="col-lg-6 text-center text-lg-end">
							<ul class="list-unstyled d-inline-flex ms-auto">
								<li class="me-4"><a href="#">Organized By <a href="#" style="color: #1472f2;font-weight: bold;">Kubana Kevin</a></a></li>
								<!-- <li><a href="#">Privacy Policy</a></li> -->
							</ul>
						</div>

					</div>
				</div>

			</div>
		</footer>
		<!-- End Footer Section -->	


		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/tiny-slider.js"></script>
		<script src="js/custom.js"></script>
	</body>

</html>
